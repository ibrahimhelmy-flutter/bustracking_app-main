import 'package:get/get.dart';/// This class is used in the [suggestion_item_widget] screen.
class SuggestionItemModel {Rx<String> group38201Txt = Rx("5.00");



String? amount;

SuggestionItemModel({this.amount});
}
