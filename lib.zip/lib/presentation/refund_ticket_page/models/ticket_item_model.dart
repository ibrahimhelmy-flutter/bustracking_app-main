import 'package:get/get.dart';/// This class is used in the [ticket_item_widget] screen.
class TicketItemModel {Rx<String>? id = Rx("");

 }
