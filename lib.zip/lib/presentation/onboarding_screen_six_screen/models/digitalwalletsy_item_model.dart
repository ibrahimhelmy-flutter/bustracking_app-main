import 'package:get/get.dart';/// This class is used in the [digitalwalletsy_item_widget] screen.
class DigitalwalletsyItemModel {Rx<String>? id = Rx("");

 }
