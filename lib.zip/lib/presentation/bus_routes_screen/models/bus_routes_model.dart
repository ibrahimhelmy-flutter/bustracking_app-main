/// This class defines the variables used in the [bus_routes_screen],
/// and is typically used to hold data that is passed between different parts of the application.
class BusRoutesModel {

 String? location;
 String? time;

 BusRoutesModel({this.location, this.time});
}
