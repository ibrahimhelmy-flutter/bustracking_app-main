import 'package:bustrackingapp/core/app_export.dart';

class ApiClient extends GetConnect {}
